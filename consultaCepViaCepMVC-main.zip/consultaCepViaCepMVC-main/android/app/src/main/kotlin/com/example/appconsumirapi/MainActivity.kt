package com.example.appconsumirapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
