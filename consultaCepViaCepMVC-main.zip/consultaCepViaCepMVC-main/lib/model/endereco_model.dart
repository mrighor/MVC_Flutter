class Endereco{
  String cep;
  String logradouro;
  String complemento;
  String bairro;
  String localidade;
  String uf;
  String ibge;

  Endereco(this.cep, this.logradouro, this.complemento, this.bairro, this.localidade,this.uf,this.ibge);

}